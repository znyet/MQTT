﻿using MQTTnet.Server;
using MQTTnet.Protocol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MQTTnet;

namespace MQTTServer
{
    class Program
    {
        static void Main(string[] args)
        {
            var option = new MqttServerOptionsBuilder()
                //.WithConnectionBacklog(100)
                .WithConnectionValidator(client =>
                {
                    if (client.ClientId.Length < 10)
                    {
                        client.ReasonCode = MqttConnectReasonCode.ClientIdentifierNotValid;
                        return;
                    }
                    if (client.Username != "admin")
                    {
                        client.ReasonCode = MqttConnectReasonCode.BadUserNameOrPassword;
                        return;
                    }
                    if (client.Password != "password")
                    {
                        client.ReasonCode = MqttConnectReasonCode.BadUserNameOrPassword;
                        return;
                    }
                    client.ReasonCode = MqttConnectReasonCode.Success;
                })
                //.WithApplicationMessageInterceptor(context =>
                //{ //消息拦截器

                //    if (context.ApplicationMessage.Topic == "my/custom/topic")
                //    {
                //        context.ApplicationMessage.Payload = Encoding.UTF8.GetBytes("The server injected payload.");
                //    }

                //    if (context.ClientId != "Some")
                //    {
                //        context.AcceptPublish = false;
                //        return;
                //    }

                //})
                //.WithSubscriptionInterceptor(context =>
                //{ //订阅拦截器

                //    if (context.TopicFilter.Topic.StartsWith("admin/foo/bar") && context.ClientId != "theAdmin")
                //    {
                //        context.AcceptSubscription = false;
                //    }

                //    if (context.TopicFilter.Topic.StartsWith("the/secret/stuff") && context.ClientId != "Imperator")
                //    {
                //        context.AcceptSubscription = false;
                //        context.CloseConnection = true;
                //    }
                //})
                .WithDefaultEndpointPort(8123)
                .Build();


            var server = new MqttFactory().CreateMqttServer();

            server.UseClientConnectedHandler(a =>
            {

                Console.WriteLine("有人连接了服务器：" + a.ClientId);
            });

            server.UseApplicationMessageReceivedHandler(a =>
            {
                Console.WriteLine("有人发送了消息：" + a.ApplicationMessage.Payload);
            });

            server.UseClientDisconnectedHandler(a =>
            {
                Console.WriteLine("有人断开了服务器：" + a.ClientId);

            });

            server.StartAsync(option);



            Console.WriteLine("mqttserver start in port：" + 8123);
            Console.ReadKey();

        }
    }
}
