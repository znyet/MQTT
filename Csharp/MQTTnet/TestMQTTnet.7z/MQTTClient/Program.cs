﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Options;
using MQTTnet.Extensions.ManagedClient;
using MQTTnet.Protocol;

namespace MQTTClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Init();
            Console.ReadKey();
        }

        private static async void Init()
        {
            var opt = new MqttClientOptionsBuilder()
                .WithTcpServer("127.0.0.1", 8123)
                .WithCredentials("admin", "password")
                .Build();

            var option = new ManagedMqttClientOptionsBuilder()
                .WithAutoReconnectDelay(TimeSpan.FromSeconds(3))
                .WithClientOptions(opt)
                .Build();

            var client = new MqttFactory().CreateManagedMqttClient();

            //订阅消息
            await client.SubscribeAsync("a", MqttQualityOfServiceLevel.AtMostOnce); //方式一

            await client.SubscribeAsync(new TopicFilterBuilder().WithTopic("my/topic").Build());//方式二

            //收到消息
            client.UseApplicationMessageReceivedHandler(a =>
            {
                Console.WriteLine(a.ApplicationMessage.Topic);
                Console.WriteLine(a.ApplicationMessage.Payload);
            });

            //连接服务器
            client.UseConnectedHandler(a =>
            {
                Console.WriteLine("连接了服务器：" + a.AuthenticateResult.ReasonString);
            });

           

            //断开连接
            client.UseDisconnectedHandler(a =>
            {
                string msg = a.ClientWasConnected.ToString();
                if (a.Exception != null)
                {
                    msg += a.Exception.Message;
                }
                if (a.AuthenticateResult != null)
                {
                    msg += a.AuthenticateResult.ResponseInformation;
                }

                Console.WriteLine("断开了连:" + msg);
            });

            await client.StartAsync(option);

            while (true)
            {
                if (client.IsConnected)
                {
                    //方式一
                    var message = new MqttApplicationMessageBuilder()
                        .WithTopic("a")
                        .WithPayload("123")
                        .WithRetainFlag(false)
                        .WithExactlyOnceQoS()
                        .Build();

                    await client.PublishAsync(message);

                    //方式二
                    await client.PublishAsync("a", "aaaa", MqttQualityOfServiceLevel.AtMostOnce); //发送消息

                    //方式三
                    await client.PublishAsync(msg =>
                    {
                        return msg
                        .WithTopic("a")
                        .WithPayload("123")
                        .WithRetainFlag(false);
                    });

                    Thread.Sleep(1000);

                }
            }

        }

    }
}
