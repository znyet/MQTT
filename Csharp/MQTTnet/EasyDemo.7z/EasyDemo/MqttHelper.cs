﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using MQTTnet;
using MQTTnet.Protocol;
using MQTTnet.Server;
using Newtonsoft.Json;
using ZLink.Cloud.MQTT.AppCode.Entity;

namespace ZLink.Cloud.MQTT.AppCode
{
    public class MqttHelper
    {
        public static IMqttServer Server;

        #region Method

        public static List<MqttClientEntity> GetClientList()
        {
            if (Server == null)
                return new List<MqttClientEntity>();
            var mqttClientList = Server.GetClientStatusAsync().Result;
            var clientList = new List<MqttClientEntity>();
            foreach (var item in mqttClientList)
            {
                var model = new MqttClientEntity();
                model.ClientId = item.ClientId;
                model.EndPoint = item.Endpoint;
                clientList.Add(model);
            }

            return clientList;
        }

        public static string GetClientJson()
        {
            return JsonConvert.SerializeObject(GetClientList());
        }

        public static void CloseClient(string clientId)
        {
            var client = Server.GetClientStatusAsync().Result.FirstOrDefault(w => w.ClientId == clientId);
            if (client != null)
                client.DisconnectAsync();
        }


        #endregion

        public static void Start()
        {
            var option = new MqttServerOptionsBuilder()
            .WithConnectionValidator(client =>
            {
                var user = ConfigHelper.UserList.FirstOrDefault(f => f.UserName == client.Username && f.Password == client.Password);
                if (user == null)
                {
                    client.ReasonCode = MqttConnectReasonCode.BadUserNameOrPassword;
                    return;
                }
                client.SessionItems.Add("topic", user.TopicList);
                client.ReasonCode = MqttConnectReasonCode.Success;

            })
                //消息拦截器
            .WithApplicationMessageInterceptor(context =>
            {

                object val;
                var ok = context.SessionItems.TryGetValue("topic", out val);
                if (ok)
                {
                    var topicList = val as List<string>;
                    if (topicList != null && topicList.Count != 0)
                    {
                        if (!topicList.Exists(w => w == context.ApplicationMessage.Topic))
                        {
                            context.AcceptPublish = false;
                        }

                    }
                }

            })
                //订阅拦截器
            .WithSubscriptionInterceptor(context =>
            {
                object val;
                var ok = context.SessionItems.TryGetValue("topic", out val);
                if (ok)
                {
                    var topicList = val as List<string>;
                    if (topicList != null && topicList.Count != 0)
                    {
                        if (!topicList.Exists(w => w == context.TopicFilter.Topic))
                        {
                            context.AcceptSubscription = false;
                        }

                    }
                }
            })
            .WithDefaultEndpointBoundIPAddress(IPAddress.Any)
            .WithDefaultEndpointPort(ConfigHelper.MqttPort)
            .Build();

            Server = new MqttFactory().CreateMqttServer();

            Server.UseClientConnectedHandler(a =>
            {
                WebSocketHelper.Broadcast(GetClientJson());
                Console.WriteLine("有人连接了服务器：" + a.ClientId);
            });

            Server.UseApplicationMessageReceivedHandler(a =>
            {
                Console.WriteLine("主题：" + a.ApplicationMessage.Topic);
                Console.WriteLine("消息：" + Encoding.UTF8.GetString(a.ApplicationMessage.Payload));
            });

            Server.UseClientDisconnectedHandler(a =>
            {
                WebSocketHelper.Broadcast(GetClientJson());
                Console.WriteLine("有人断开了服务器：" + a.ClientId);
            });

            Server.StartAsync(option);
        }

        public static void Stop()
        {
            if (Server != null)
                Server.StopAsync();
        }

    }
}
