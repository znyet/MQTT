﻿using System;
using System.Collections.Generic;
using System.Linq;
using SharpConfig;
using ZLink.Cloud.MQTT.AppCode.Entity;

namespace ZLink.Cloud.MQTT.AppCode
{
    public class ConfigHelper
    {
        public static string ApplicationPath
        {
            get { return AppDomain.CurrentDomain.BaseDirectory; }
        }

        private static Configuration _config;

        public static void Init()
        {
            _config = Configuration.LoadFromFile(ApplicationPath + "/AppConfig/App.ini");
        }

        #region Section

        private static Section UserSection
        {
            get { return _config["user"]; }
        }

        private static Section TopicSection
        {
            get { return _config["topic"]; }
        }

        private static Section MqttSection
        {
            get { return _config["mqtt"]; }
        }

        private static Section WebSocketSection
        {
            get { return _config["websocket"]; }
        }

        #endregion

        public static int MqttPort
        {
            get { return MqttSection["port"].IntValue; }
        }


        public static int WebSocketPort
        {
            get { return WebSocketSection["port"].IntValue; }
        }

        public static int WebSocketIdle
        {
            get { return WebSocketSection["idle"].IntValue; }
        }


        #region 用户

        private static List<UserInfo> _userList;

        public static List<UserInfo> UserList
        {
            get
            {
                if (_userList == null)
                {
                    _userList = new List<UserInfo>();
                    foreach (var item in UserSection)
                    {
                        var user = new UserInfo();
                        user.UserName = item.Name;
                        user.Password = item.StringValue;
                        if (TopicSection.Contains(item.Name))
                        {
                            var topicString = TopicSection[item.Name].StringValue;
                            user.TopicList = topicString.Split(new string[] { ",","，" }, StringSplitOptions.RemoveEmptyEntries).ToList();   
                        }
                        else
                        {
                            user.TopicList = new List<string>();
                        }
                        _userList.Add(user);
                    }
                }
                return _userList;
            }
        }


        #endregion

    }
}
