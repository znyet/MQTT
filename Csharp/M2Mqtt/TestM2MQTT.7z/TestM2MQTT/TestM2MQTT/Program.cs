﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace TestM2MQTT
{
    class Program
    {
        private static MqttClient client;
        static bool IsConnect = false;

        static void Main(string[] args)
        {
            client = new MqttClient("127.0.0.1", 8123, false, null, null, MqttSslProtocols.TLSv1_2);
            client.MqttMsgPublishReceived += (sender, e) =>
            {
                Console.WriteLine(e.Topic + "：" + e.Message);
            };
            client.ConnectionClosed += (sender, e) =>
            {
                Console.WriteLine("服务器断开连接...");
                IsConnect = false;
                Connect();
            };

            Connect();

            while (true)
            {
                Thread.Sleep(1000);
                client.Publish("a", new byte[] { 1 });
            }

            Console.ReadKey();
        }


        private static void Connect()
        {
            var id = Guid.NewGuid().ToString("N");
            while (!IsConnect)
            {
                try
                {
                    client.Connect(id, "admin", "password");
                    IsConnect = true;
                    client.Subscribe(new[] { "a" }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE });
                    client.Subscribe(new[] { "b" }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE });
                    Console.WriteLine("连接成功...");
                }
                catch
                {
                    Console.WriteLine("连接失败,断线重连中...");
                    Thread.Sleep(3000); //3秒断线重连
                }
            }

        }

    }
}
